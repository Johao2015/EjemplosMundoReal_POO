# Ejemplos del Mundo Real - Programación Orientada a Objetos (POO)

## Descripción del Caso
Este proyecto implementa un **Sistema de Reservas de Hotel** como ejemplo del mundo real para demostrar
los conceptos fundamentales de la Programación Orientada a Objetos (POO) en Python.

## Clases Utilizadas
- **Cliente**: Representa a la persona que realiza la reserva.
- **Habitacion**: Representa una habitación del hotel.
- **Reserva**: Gestiona la relación entre cliente y habitación.

## Conceptos de POO Aplicados
- Clases y objetos
- Atributos y métodos
- Encapsulación
- Interacción entre objetos

## Ejecución
Para ejecutar el programa:
```bash
python sistema_reservas_hotel.py
```

## Autor
Trabajo académico – Ejemplo educativo
