# Sistema de Reservas de Hotel
# Ejemplo del mundo real usando Programación Orientada a Objetos (POO)

class Cliente:
    def __init__(self, nombre, cedula):
        self.nombre = nombre
        self.cedula = cedula

    def mostrar_datos(self):
        return f"Cliente: {self.nombre}, Cédula: {self.cedula}"


class Habitacion:
    def __init__(self, numero, tipo, precio):
        self.numero = numero
        self.tipo = tipo
        self.precio = precio
        self.disponible = True

    def ocupar(self):
        self.disponible = False

    def liberar(self):
        self.disponible = True


class Reserva:
    def __init__(self, cliente, habitacion, dias):
        self.cliente = cliente
        self.habitacion = habitacion
        self.dias = dias

    def confirmar_reserva(self):
        if self.habitacion.disponible:
            self.habitacion.ocupar()
            total = self.dias * self.habitacion.precio
            return (
                f"Reserva confirmada\n"
                f"{self.cliente.mostrar_datos()}\n"
                f"Habitación Nº {self.habitacion.numero} ({self.habitacion.tipo})\n"
                f"Días: {self.dias}\n"
                f"Total a pagar: ${total}"
            )
        else:
            return "La habitación no está disponible"


if __name__ == "__main__":
    cliente1 = Cliente("Juan Pérez", "0102030405")
    habitacion1 = Habitacion(101, "Matrimonial", 50)
    reserva1 = Reserva(cliente1, habitacion1, 3)
    print(reserva1.confirmar_reserva())
